import 'dart:io';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class FeedbackPage extends StatelessWidget {
  final File imageFile;
  final String mood;

  FeedbackPage({required this.imageFile, required this.mood});

  final Map<String, String> moodMelodies = {
    'calm': 'calm.mp3',
    'happy': 'happy.mp3',
    'sad': 'sad.mp3',
  };

  @override
  Widget build(BuildContext context) {
    final player = AudioPlayer();
    final melodyPath = 'music/\${moodMelodies[mood] ?? 'calm.mp3'}';

    return Scaffold(
      appBar: AppBar(title: Text('추천 결과')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.file(imageFile, height: 200),
            ),
            SizedBox(height: 20),
            Text(
              '분위기 분석 결과: \${mood.toUpperCase()}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 30),
            ElevatedButton.icon(
              icon: Icon(Icons.play_circle_fill),
              label: Text('추천 멜로디 재생'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                minimumSize: Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              onPressed: () async {
                await player.play(AssetSource(melodyPath));
              },
            ),
          ],
        ),
      ),
    );
  }
}
