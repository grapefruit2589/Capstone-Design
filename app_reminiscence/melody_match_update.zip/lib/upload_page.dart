import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'feedback_page.dart';

class UploadPage extends StatefulWidget {
  @override
  _UploadPageState createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  File? _selectedImage;

  Future<void> _pickImage() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result != null) {
      setState(() {
        _selectedImage = File(result.files.single.path!);
      });
    }
  }

  void _analyzeAndGoToFeedback() {
    String mood = 'calm'; // 추후 자동 분석으로 교체 가능
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FeedbackPage(
          imageFile: _selectedImage!,
          mood: mood,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('추억 사진 업로드')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            _selectedImage != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.file(_selectedImage!, height: 200))
                : Container(
                    height: 200,
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.grey),
                    ),
                    child: Center(child: Text('사진 미리보기')),
                  ),
            SizedBox(height: 30),
            ElevatedButton.icon(
              icon: Icon(Icons.image_search),
              label: Text('사진 선택하기'),
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 50),
                backgroundColor: Colors.blueAccent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              onPressed: _pickImage,
            ),
            SizedBox(height: 20),
            if (_selectedImage != null)
              ElevatedButton.icon(
                icon: Icon(Icons.music_note),
                label: Text('사진 분석하고 멜로디 추천'),
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                  backgroundColor: Colors.deepPurple,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                onPressed: _analyzeAndGoToFeedback,
              ),
          ],
        ),
      ),
    );
  }
}
