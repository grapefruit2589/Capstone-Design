
import 'package:flutter/material.dart';

class MoodTagDisplay extends StatelessWidget {
  final String moodTag;

  MoodTagDisplay({required this.moodTag});

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(moodTag),
      backgroundColor: Colors.blue.shade100,
    );
  }
}
