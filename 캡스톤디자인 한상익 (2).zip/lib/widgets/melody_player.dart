
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class MelodyPlayer extends StatefulWidget {
  final String filePath;

  MelodyPlayer({required this.filePath});

  @override
  _MelodyPlayerState createState() => _MelodyPlayerState();
}

class _MelodyPlayerState extends State<MelodyPlayer> {
  final AudioPlayer _audioPlayer = AudioPlayer();

  void _play() {
    _audioPlayer.play(DeviceFileSource(widget.filePath));
  }

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: _play,
      child: Text("멜로디 재생"),
    );
  }
}
