
import 'package:flutter/material.dart';

class FeedbackForm extends StatelessWidget {
  final Function(bool) onFeedback;

  FeedbackForm({required this.onFeedback});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text('멜로디와 분위기가 어울리나요?'),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => onFeedback(true),
              child: Text("잘 어울려요"),
            ),
            SizedBox(width: 10),
            ElevatedButton(
              onPressed: () => onFeedback(false),
              child: Text("어색해요"),
            ),
          ],
        ),
      ],
    );
  }
}
