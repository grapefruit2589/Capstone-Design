
import 'package:flutter/material.dart';
import '../widgets/mood_tag_display.dart';
import '../widgets/melody_player.dart';

class ResultScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    String mood = 'nostalgic';
    String melodyPath = 'assets/melodies/nostalgic.mp3';

    return Scaffold(
      appBar: AppBar(title: Text('분석 결과')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          MoodTagDisplay(moodTag: mood),
          MelodyPlayer(filePath: melodyPath),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, '/feedback'),
            child: Text('피드백 남기기'),
          )
        ],
      ),
    );
  }
}
