
import 'package:flutter/material.dart';
import '../widgets/photo_picker.dart';

class UploadScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('사진 업로드')),
      body: Center(
        child: PhotoPicker(
          onImageSelected: (image) {
            Navigator.pushNamed(context, '/result');
          },
        ),
      ),
    );
  }
}
