
import 'package:flutter/material.dart';
import '../widgets/feedback_form.dart';

class FeedbackScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('피드백')),
      body: Center(
        child: FeedbackForm(
          onFeedback: (isPositive) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(isPositive ? '감사합니다!' : '참고하겠습니다!')),
            );
          },
        ),
      ),
    );
  }
}
